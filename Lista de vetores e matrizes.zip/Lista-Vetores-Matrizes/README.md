# Lista 02 - Programação Imperativa

Soluções em Java da Lista 02 de Programação Imperativa.

## Estrutura

- `vetores/` — questões 1 a 13 de Vetores.
- `matrizes/` — questões 1 a 14 de Matrizes.

Cada questão está em seu próprio arquivo `.java`, conforme a instrução da lista.

## Como executar

Entre na pasta da questão e compile:

```bash
javac q1.java
java q1
```

Altere `q1` para o número da questão desejada.

## Observações

- A questão 5 de Vetores interpreta "posições pares" como os índices 0, 2, 4, ... do vetor.
- A questão 12 de Matrizes informa 2 x 2 para as matrizes de entrada, mas menciona uma terceira matriz 3 x 3. Como a operação entre matrizes 2 x 2 produz naturalmente outra 2 x 2, a implementação usa uma terceira matriz 2 x 2.
- A questão 13 de Matrizes informa 200 lugares, mas também especifica 10 fileiras com 10 cadeiras cada (100 posições). A implementação segue a estrutura 10 x 10 indicada no enunciado.
